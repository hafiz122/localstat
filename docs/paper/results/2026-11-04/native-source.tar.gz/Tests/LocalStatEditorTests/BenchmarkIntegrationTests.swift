import AppKit
import CryptoKit
import XCTest
@testable import LocalStat
import SASCore

final class BenchmarkIntegrationTests: XCTestCase {
    @MainActor func testMeasuredRuns() async throws {
        guard let configPath = ProcessInfo.processInfo.environment["LOCALSTAT_BENCHMARK_CONFIG"] else {
            throw XCTSkip("Opt-in measurement: set LOCALSTAT_BENCHMARK_CONFIG")
        }
        let configURL = URL(fileURLWithPath: configPath)
        let config = try XCTUnwrap(JSONSerialization.jsonObject(with: Data(contentsOf: configURL)) as? [String: Any])
        let binary = URL(fileURLWithPath: try XCTUnwrap(config["binary"] as? String))
        let work = URL(fileURLWithPath: try XCTUnwrap(config["work"] as? String))
        let output = URL(fileURLWithPath: try XCTUnwrap(config["output"] as? String))
        XCTAssertFalse(FileManager.default.fileExists(atPath: output.path), "Do not overwrite an experiment")
        let cases = try XCTUnwrap(config["cases"] as? [[String: Any]])
        let warmups = try XCTUnwrap(config["warmups"] as? Int)
        let repetitions = try XCTUnwrap(config["repetitions"] as? Int)
        _ = NSApplication.shared
        let oldAppearance = NSApp.appearance
        defer { NSApp.appearance = oldAppearance }
        var samples: [[String: Any]] = []
        for item in cases {
            let name = try XCTUnwrap(item["name"] as? String)
            let rows = try XCTUnwrap(item["rows"] as? Int)
            let folder = work.appendingPathComponent(try XCTUnwrap(item["directory"] as? String))
            let source = try String(contentsOf: folder.appendingPathComponent(try XCTUnwrap(item["source"] as? String)), encoding: .utf8)
            let suite = "LocalStatBenchmark.\(UUID().uuidString)"
            let defaults = try XCTUnwrap(UserDefaults(suiteName: suite))
            let app = AppDelegate()
            app.appearanceDefaults = defaults
            app.projectURL = folder
            let runner = LocalRuntimeRunner(executable: binary)
            app.runner = runner
            app.buildWindow()
            app.window.appearance = NSAppearance(named: .aqua)
            app.window.setFrame(NSRect(x: 100, y: 100, width: 1100, height: 780), display: true)
            app.addDocument(EditorDocument(url: nil, source: source))
            app.window.orderFront(nil)
            defer {
                app.window.delegate = nil
                app.window.close()
                defaults.removePersistentDomain(forName: suite)
            }
            for iteration in 0..<(1 + warmups + repetitions) {
                let phase = iteration == 0 ? "first" : (iteration <= warmups ? "warmup" : "measured")
                for variant in (iteration % 2 == 0 ? ["runner", "app"] : ["app", "runner"]) {
                let start = DispatchTime.now().uptimeNanoseconds
                let result: RunResult
                if variant == "runner" {
                    result = await runner.run(RunRequest(source: source, sourceURL: nil, workingDirectory: folder))
                } else {
                    app.runProgram()
                    while app.lastResult == nil && DispatchTime.now().uptimeNanoseconds - start < 60_000_000_000 {
                        try await Task.sleep(nanoseconds: 1_000_000)
                    }
                    guard let finished = app.lastResult else {
                        runner.cancel()
                        XCTFail("Benchmark timed out: \(name) \(rows)")
                        return
                    }
                    result = finished
                    app.window.contentView?.layoutSubtreeIfNeeded()
                    app.window.displayIfNeeded()
                }
                let elapsed = Double(DispatchTime.now().uptimeNanoseconds - start) / 1e9
                XCTAssertEqual(result.status, .success)
                XCTAssertNil(result.tableIssue)
                let expectedTables = ["freq", "print"].contains(name) ? 1 : 0
                XCTAssertEqual(result.tables.count, expectedTables)
                let hash = SHA256.hash(data: Data(result.output.utf8)).map { String(format: "%02x", $0) }.joined()
                samples.append(["workload": name, "rows": rows, "phase": phase, "iteration": iteration,
                                "status": result.status == .success && result.tableIssue == nil ? "ok" : "invalid",
                                "wall_s": elapsed, "variant": variant,
                                "stdout_sha256": hash, "table_count": result.tables.count,
                                "table_rows": result.tables.reduce(0) { $0 + $1.rows.count }])
                try JSONSerialization.data(withJSONObject: samples, options: [.prettyPrinted, .sortedKeys]).write(to: output, options: .atomic)
                }
            }
        }
    }
}
